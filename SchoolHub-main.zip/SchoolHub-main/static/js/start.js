console.log("This is running");
const loginButtonID = "signUpButton";   

function pressed() {
    // window.location.href = "http://www.w3schools.com";
}   

